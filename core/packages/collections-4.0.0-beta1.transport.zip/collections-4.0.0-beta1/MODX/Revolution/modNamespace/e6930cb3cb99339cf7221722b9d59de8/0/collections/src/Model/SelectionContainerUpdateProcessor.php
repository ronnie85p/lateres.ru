<?php
namespace Collections\Model;

class SelectionContainerUpdateProcessor extends CollectionContainerUpdateProcessor
{
    public function afterSave()
    {
        return parent::afterSave();
    }
}
