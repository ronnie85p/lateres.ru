<?php
$xpdo_meta_map = array (
    'version' => '3.0',
    'namespace' => 'Collections\\Model',
    'namespacePrefix' => 'Collections',
    'class_map' => 
    array (
        'MODX\\Revolution\\modResource' => 
        array (
            0 => 'Collections\\Model\\CollectionContainer',
        ),
        'Collections\\Model\\CollectionContainer' => 
        array (
            0 => 'Collections\\Model\\SelectionContainer',
        ),
        'xPDO\\Om\\xPDOSimpleObject' => 
        array (
            0 => 'Collections\\Model\\CollectionSetting',
            1 => 'Collections\\Model\\CollectionTemplate',
            2 => 'Collections\\Model\\CollectionTemplateColumn',
        ),
        'xPDO\\Om\\xPDOObject' => 
        array (
            0 => 'Collections\\Model\\CollectionResourceTemplate',
            1 => 'Collections\\Model\\CollectionSelection',
        ),
    ),
);