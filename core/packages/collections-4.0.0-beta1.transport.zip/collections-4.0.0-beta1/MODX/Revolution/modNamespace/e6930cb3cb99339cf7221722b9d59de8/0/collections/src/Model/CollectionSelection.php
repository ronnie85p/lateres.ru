<?php
namespace Collections\Model;

use xPDO\xPDO;

/**
 * Class CollectionSelection
 *
 * @property integer $collection
 * @property integer $resource
 * @property integer $menuindex
 *
 * @package Collections\Model
 */
class CollectionSelection extends \xPDO\Om\xPDOObject
{
}
