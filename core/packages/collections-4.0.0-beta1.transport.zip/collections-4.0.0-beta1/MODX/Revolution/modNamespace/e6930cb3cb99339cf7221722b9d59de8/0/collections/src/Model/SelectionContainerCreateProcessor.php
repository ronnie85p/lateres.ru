<?php
namespace Collections\Model;

class SelectionContainerCreateProcessor extends CollectionContainerCreateProcessor
{
    public function afterSave()
    {
        return parent::afterSave();
    }
}
