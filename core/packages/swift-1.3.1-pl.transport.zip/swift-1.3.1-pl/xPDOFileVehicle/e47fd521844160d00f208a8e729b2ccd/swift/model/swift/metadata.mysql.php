<?php
$xpdo_meta_map = array (
    'version' => '3.0',
    'namespace' => 'swift',
    'namespacePrefix' => '',
    'class_map' => 
    array (
        'MODX\\Revolution\\sources\\modMediaSource' => 
        array (
            0 => 'swift\\SwiftMediaSource',
        ),
        'MODX\\Revolution\\sources\\SwiftMediaSource' => 
        array (
            0 => 'swift\\RackspaceMediaSource',
        ),
    ),
);