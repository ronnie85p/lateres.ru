<?php

require_once __DIR__ . '/vendor/autoload.php';

$modx->classMap['MODX\\Revolution\\sources\\modMediaSource'][] = 'SwiftMediaSource';