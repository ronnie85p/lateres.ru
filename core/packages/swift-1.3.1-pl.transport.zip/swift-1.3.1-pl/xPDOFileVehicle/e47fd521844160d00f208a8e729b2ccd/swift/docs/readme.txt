--------------------
MODX Swift
--------------------

Author: Evgeny Duryagin <hello@evd.me>
Author: Vasily Naumkin <bezumkin@yandex.ru>
License: GNU GPLv2

OpenStack Object Storage (code-named Swift) media source type for MODX 2.3+.

Source code: https://github.com/bezumkin/modx-swift
