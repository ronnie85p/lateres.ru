<?php

$xpdo_meta_map = array(
    'modResource' =>
        array(
            0 => 'msCategory',
            1 => 'msProduct',
        ),
    'xPDOSimpleObject' =>
        array(
            0 => 'msProductData',
            1 => 'msVendor',
            2 => 'msProductFile',
            3 => 'msDelivery',
            4 => 'msPayment',
            5 => 'msOrder',
            6 => 'msOrderStatus',
            7 => 'msOrderLog',
            8 => 'msOrderAddress',
            9 => 'msOrderProduct',
            10 => 'msLink',
            11 => 'msOption',
        ),
    'xPDOObject' =>
        array(
            0 => 'msCategoryMember',
            1 => 'msProductOption',
            2 => 'msDeliveryMember',
            3 => 'msProductLink',
            4 => 'msCustomerProfile',
            5 => 'msCategoryOption',
        ),
);
