<?php

require_once(dirname(dirname(__FILE__)) . '/msproduct.class.php');
class msProduct_mysql extends msProduct
{
}
