<?php

require_once __DIR__ . '/model/minishop2/minishop2.class.php';

$modx->services->add('minishop2', new miniShop2($modx));