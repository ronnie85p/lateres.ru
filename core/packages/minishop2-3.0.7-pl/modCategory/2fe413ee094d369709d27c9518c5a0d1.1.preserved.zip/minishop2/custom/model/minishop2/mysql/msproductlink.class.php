<?php

require_once(dirname(dirname(__FILE__)) . '/msproductlink.class.php');
class msProductLink_mysql extends msProductLink
{
}
