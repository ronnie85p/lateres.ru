<?php

use MODX\Revolution\Processors\Model\GetProcessor;

class msProductGetProcessor extends GetProcessor
{
    public $classKey = 'msProduct';
    public $languageTopics = ['minishop2:default'];
}

return 'msProductGetProcessor';
